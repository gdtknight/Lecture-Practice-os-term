#define DISK_SUCCESS	0
#define DISK_FAIL		1

#define NO_OF_SECTORS	1024
